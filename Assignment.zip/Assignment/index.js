// Variables
let s = 45;
let d = 50;
let c = 120;
let e = 70;
let linebreak = "<br />";

// === COMPARISON OPERATORS ===
document.write("<h3>COMPARISON OPERATORS</h3>");
document.write("s == d: " + (s == d) + linebreak);
document.write("s != d: " + (s != d) + linebreak);
document.write("s > d: " + (s > d) + linebreak);
document.write("s < d: " + (s < d) + linebreak);
document.write("s >= d: " + (s >= d) + linebreak);
document.write("s <= d: " + (s <= d) + linebreak);

document.write(linebreak);

document.write("c > e: " + (c > e) + linebreak);
document.write("c <= e: " + (c <= e) + linebreak);
document.write("c === e: " + (c === e) + linebreak);

document.write(linebreak);

// === LOGICAL OPERATORS ===
document.write("<h3>LOGICAL OPERATORS</h3>");
document.write("s < d && c > e: " + (s < d && c > e) + linebreak);
document.write("s > d && e > c: " + (s > d && e > c) + linebreak);

document.write("s < d || e > c: " + (s < d || e > c) + linebreak);
document.write("s > d || e < c: " + (s > d || e < c) + linebreak);

document.write("!(s > d): " + (!(s > d)) + linebreak);
document.write("!(c < e): " + (!(c < e)) + linebreak);
