// var1 = 10;
// var2 = 20;
// window.alert(var1);
// window.alert(var2);
// console.log(var1, var2);
// document.write(var1);
// document.write(var2);

// const add = var1 + var2
// console.log(add);
// const sub = var1 - var2
// console.log(sub);
// const mul = var1 * var2
// console.log(mul);
// const div = var1 / var2
// console.log(div)
// const mod = var1 % var2
// console.log(mod);

// var name = "Ali";
// console.log(name);
// var money;
// console.log(money);
// money = 2000.5;
// console.log(money);

// var myVar = "Hello"; //global variable
// function checkscope() {
//   lastname = "Bode"; //local variable
//   // console.log(lastname);
//   // greet = myVar + " " + lastname;
//   // document.write(greet);
//   return lastname;
// }

// checkscope();
// console.log(checkscope())

// var loq = "i";
// var hi = "I";
// var a = 33;
// var b = 10;
// var c = "Test";
// var linebreak = "<br />";

// loq === hi ? console.log("low is equal to hi") : console.log("loq is not equal to hi");
// hi == loq ? console.log("low is equal to hi") : console.log("loq is not equal to hi");
// a === b ? console.log("a is equal to b") : console.log("a is not equal to b");
// a!= b ? console.log("a is not equal to b") : console.log("a is equal to b");
// a > b ? console.log("a is greater than b") : console.log("a is not greater than b");
// a < b ? console.log("a is less than b") : console.log("a is not less than b");

// merge = a + b
// console.log(merge)

// document.write("a + b = ");
// result = a + b;
// document.write(result);
// document.write(linebreak);

// var example = var1 == var2;
// console.log(example);
// var example = var1 != var2
// console.log(example)
// var example = var1 < var2
// console.log(example)
// var example = var1 > var2
// console.log(example)
// var example = var1 >= var2
// console.log(example)

// var var1=150
// var var2 =150
// var example = var1 <= var2
// console.log(example)

// var a = true;
// var b = true;
// var linebreak = "<br />";

// document.write("(a &&  b) => ");
// result = a && b;
// document.write(result);
// document.write(linebreak);

// document.write("(a || b) => ");
// result = a || b;
// document.write(result);
// document.write(linebreak);

// document.write("!(a && b) => ");
// result = !(a && b);
// document.write(result);
// document.write(linebreak);

// exercise
s = 45;
d = 50;
c = 120;
e = 70;
linebreak = "<br />"


document.write(linebreak);


